

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/delete")
public class delete extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		PrintWriter out=response.getWriter();
		
		try
		{
			Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/ambulance?serverTimezone=UTC", "root", "");
			PreparedStatement ps3 = con.prepareStatement("delete from bookamb where Name = ?");
        	ps3.setString(1, request.getParameter("name"));
        	if((ps3.executeUpdate())>0) {
            	out.println("Successfully Deleted");
            	response.sendRedirect("details.jsp");
            	
            	
            }
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
