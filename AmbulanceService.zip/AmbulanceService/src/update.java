

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/update")
public class update extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		PrintWriter out=response.getWriter();
		try
		{
			Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/ambulance?serverTimezone=UTC", "root", "");
			
			String upname=request.getParameter("names");
			PreparedStatement st = con.prepareStatement("update bookamb set Department=?,Ambulance=?,Name=?,PhoneNo=? where Name=?"); 
			
			 st.setString(1, request.getParameter("dep")); 
	         st.setString(2, request.getParameter("amb")); 
	         st.setString(3, request.getParameter("name")); 
	         st.setString(4, request.getParameter("phoneno"));
	         st.setString(5,upname);
	         if((st.executeUpdate())>0) 
	         {
	            out.println("Successfully Updated");
	            response.sendRedirect("details.jsp");
			
	         }
		}catch(Exception e)
		{
			e.printStackTrace();
			
		}
	}

}
